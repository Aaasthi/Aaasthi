# FinServ Site - Starter

This repository is a starter scaffold for a financial services consultant website.
It includes:
- Full frontend (Next.js App Router) with pages: Home, Services, Blog, Contact
- Simple Admin panel (protected by an env secret) to manage content
- Backend API routes for leads and content
- Prisma schema and SQL migration for PostgreSQL

## Quick setup (local)

1. Copy `.env.example` to `.env` and fill values.
2. Install deps:
   ```
   npm install
   ```
3. Generate Prisma client and run migrations:
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   ```
4. Run dev server:
   ```
   npm run dev
   ```

## Deploy
- Configure environment variables on your hosting provider.
- Build and start: `npm run build && npm start`

